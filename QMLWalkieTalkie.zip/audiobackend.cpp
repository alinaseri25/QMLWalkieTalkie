#include "audiobackend.h"
#include <qdebug.h>

AudioBackend::AudioBackend(QObject *parent)
    : QObject{parent}
{

}

void AudioBackend::onSettingapplied(int myId, int sendToId, int inputDeviceIndex, int outputDeviceIndex)
{
    qDebug() << QString("myId : %1").arg(myId);
    emit setWindowsTittle(QString("Test"));
}
